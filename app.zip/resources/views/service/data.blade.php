@extends('layouts.main')
@section('inivaluenya')
    
    @include('serpihan.produk')

    @include('serpihan.solusibisnis')
    
@endsection