@extends('layouts.main')
@section('inivaluenya')

    @include('serpihan.bannerutama')

    @include('serpihan.tagline')

   @include('serpihan.service')

   @include('serpihan.solusibisnis')

   @include('serpihan.fitursistem')

   @include('serpihan.produk')

   @include('serpihan.support')

   @include('serpihan.faq')

   @include('serpihan.ketentuan')
  
@endsection