@extends('layouts.main')
@section('inivaluenya')
    
    @include('serpihan.ketentuan')

    @include('serpihan.solusibisnis')
    
@endsection