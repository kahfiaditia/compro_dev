@extends('layouts.main')
@section('inivaluenya')
    
    @include('serpihan.faq')

    @include('serpihan.solusibisnis')
    
@endsection