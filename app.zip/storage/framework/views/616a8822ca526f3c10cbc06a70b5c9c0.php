
<?php $__env->startSection('inivaluenya'); ?>
    
    <?php echo $__env->make('serpihan.produk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('serpihan.solusibisnis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pekerjaan\compro_dev\resources\views/service/data.blade.php ENDPATH**/ ?>